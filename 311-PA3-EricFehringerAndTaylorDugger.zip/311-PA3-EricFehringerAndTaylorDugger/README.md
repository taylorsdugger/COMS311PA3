Eric Fehringer
Taylor Dugger